// 
// Decompiled by Procyon v0.5.36
// 

public interface Logger
{
    void writeToLog(final String p0);
}
