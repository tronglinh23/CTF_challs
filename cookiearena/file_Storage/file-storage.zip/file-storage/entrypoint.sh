#!/bin/sh

mv /flag.txt /flag

exec "$@"